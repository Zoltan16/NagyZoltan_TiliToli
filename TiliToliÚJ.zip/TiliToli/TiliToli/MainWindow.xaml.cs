﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.PerformanceData;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation.Peers;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TiliToliÚJ
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        int[] allas = { 1, 2, 3, 4, 5, 6, 7, 8, 0 };
        int[] kesz = { 1, 2, 3, 4, 5, 6, 7, 8, 0 };
        int lepes = 0;

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button ezGomb = sender as Button;
            Button nullaGomb = (Button)FindName("Button0");
            var fTav = Math.Abs(ezGomb.Margin.Top - nullaGomb.Margin.Top);
            var vTav = Math.Abs(ezGomb.Margin.Left - nullaGomb.Margin.Left);

            //A tömben elfoglalt pozíció
            int ezGombFelirat = int.Parse(ezGomb.Content.ToString());
            int ezGombIndex = Array.IndexOf(allas, ezGombFelirat);
            int nullaGombIndex = Array.IndexOf(allas, 0);

            if ((fTav == 100 && vTav == 0) || (vTav == 100 && fTav == 0))
            {
                var seged = ezGomb.Margin;
                ezGomb.Margin = nullaGomb.Margin;
                nullaGomb.Margin = seged;
                lepes++;
            }

            allas[nullaGombIndex] = allas[ezGombFelirat];
            allas[ezGombFelirat] = 0;

            //Mikor lesz vége?
            if (allas.SequenceEqual(kesz))
            {
                //Mit csináljon ha kész
                MessageBox.Show("Gratulálok, befejezte a feladványt! Szeretne egy újat játszani?");
            }

            szamlalo.Content = "A lépések száma: " + lepes;
        }



        private void kevero_Click(object sender, RoutedEventArgs e)
        {


            szamlalo.Content = "A lépések száma: 0";

            int[] allas = { 1, 2, 3, 4, 5, 6, 7, 8, 0 };
            Random r = new Random();
            List<int> vanebenne = new List<int>();

            do
            {
                int x = r.Next(1, 9);
                if (vanebenne.Contains(x))
                {

                }
                else
                {
                    vanebenne.Add(x);
                }
            } while (vanebenne.Count != 8);

            for (int i = 0; i < 8; i++)
            {

                allas[i] = vanebenne[i];
            }



            for (int i = 0; i < 8; i++)
            {
                if (i == 0)
                {
                    Button1.Content = allas[i];
                }
                else if (i == 1)
                {
                    Button2.Content = allas[i];
                }
                else if (i == 2)
                {
                    Button3.Content = allas[i];
                }
                else if (i == 3)
                {
                    Button4.Content = allas[i];
                }
                else if (i == 4)
                {
                    Button5.Content = allas[i];
                }
                else if (i == 5)
                {
                    Button6.Content = allas[i];
                }
                else if (i == 6)
                {
                    Button7.Content = allas[i];
                }
                else
                {
                    Button8.Content = allas[i];
                }
                if (allas==kesz)
                {
                    MessageBox.Show("Gratulálok, befejezte a feladványt! Szeretne egy újat játszani?");
                }
            }
        }
    }
}
